# Stock-Price-Analysis
A Django-based website for stock price analysis; containerized using Docker.
